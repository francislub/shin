import { type NextRequest, NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import jwt from "jsonwebtoken"

// Calculate grade based on percentage
const calculateGrade = (marks: number, totalMarks: number): string => {
  const percentage = (marks / totalMarks) * 100

  if (percentage >= 90) return "A+"
  if (percentage >= 80) return "A"
  if (percentage >= 70) return "B+"
  if (percentage >= 60) return "B"
  if (percentage >= 50) return "C+"
  if (percentage >= 40) return "C"
  if (percentage >= 30) return "D"
  return "F"
}

export async function GET(request: NextRequest) {
  try {
    // Get token from Authorization header
    const authHeader = request.headers.get("authorization")

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ error: "No token provided" }, { status: 401 })
    }

    const token = authHeader.substring(7)

    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any

    if (decoded.role !== "Teacher") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
    }

    const { searchParams } = new URL(request.url)
    const classId = searchParams.get("classId")
    const subjectId = searchParams.get("subjectId")
    const examType = searchParams.get("examType")

    if (!classId || !subjectId || !examType) {
      return NextResponse.json({ error: "Class ID, Subject ID, and Exam Type are required" }, { status: 400 })
    }

    console.log("Fetching results for class:", classId, "subject:", subjectId, "examType:", examType)

    // Get exam results for the specified criteria
    const results = await prisma.examResult.findMany({
      where: {
        subjectId: subjectId,
        examType: examType,
        student: {
          sclassId: classId,
        },
      },
      include: {
        student: {
          select: {
            id: true,
            name: true,
            rollNum: true,
            admissionNumber: true,
          },
        },
        subject: {
          select: {
            id: true,
            subName: true,
            subCode: true,
          },
        },
      },
      orderBy: {
        student: {
          rollNum: "asc",
        },
      },
    })

    console.log("Found results:", results.length)

    return NextResponse.json({
      success: true,
      results: results,
    })
  } catch (error) {
    console.error("Get results error:", error)
    return NextResponse.json({ error: "Failed to fetch results" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    // Get token from Authorization header
    const authHeader = request.headers.get("authorization")

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ error: "No token provided" }, { status: 401 })
    }

    const token = authHeader.substring(7)

    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any

    if (decoded.role !== "Teacher") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
    }

    const body = await request.json()
    const { classId, subjectId, examType, totalMarks, students } = body

    if (!classId || !subjectId || !examType || !totalMarks || !students || !Array.isArray(students)) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    console.log("Saving marks for:", { classId, subjectId, examType, totalMarks, studentsCount: students.length })

    // Get the current term (you might need to adjust this based on your schema)
    const currentTerm = await prisma.term.findFirst({
      where: {
        isCurrent: true,
      },
    })

    if (!currentTerm) {
      return NextResponse.json({ error: "No current term found" }, { status: 400 })
    }

    // Process each student's marks
    const results = []

    for (const studentData of students) {
      const { studentId, marksObtained } = studentData

      if (!studentId || marksObtained === undefined || marksObtained === null) {
        continue
      }

      const grade = calculateGrade(marksObtained, totalMarks)

      // Check if result already exists
      const existingResult = await prisma.examResult.findFirst({
        where: {
          studentId: studentId,
          subjectId: subjectId,
          examType: examType,
          termId: currentTerm.id,
        },
      })

      if (existingResult) {
        // Update existing result
        const updatedResult = await prisma.examResult.update({
          where: {
            id: existingResult.id,
          },
          data: {
            marksObtained: marksObtained,
            totalMarks: totalMarks,
            grade: grade,
          },
          include: {
            student: {
              select: {
                name: true,
                rollNum: true,
              },
            },
          },
        })
        results.push(updatedResult)
      } else {
        // Create new result
        const newResult = await prisma.examResult.create({
          data: {
            studentId: studentId,
            subjectId: subjectId,
            examType: examType,
            marksObtained: marksObtained,
            totalMarks: totalMarks,
            grade: grade,
            termId: currentTerm.id,
          },
          include: {
            student: {
              select: {
                name: true,
                rollNum: true,
              },
            },
          },
        })
        results.push(newResult)
      }
    }

    console.log("Successfully saved marks for", results.length, "students")

    return NextResponse.json({
      success: true,
      message: `Successfully saved marks for ${results.length} students`,
      results: results,
    })
  } catch (error) {
    console.error("Save marks error:", error)
    return NextResponse.json({ error: "Failed to save marks" }, { status: 500 })
  }
}
