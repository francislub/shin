import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import prisma from "@/lib/prisma"

export async function GET(request: NextRequest) {
  try {
    const session = await getSession()
    if (!session || session.role !== "Admin") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const termId = searchParams.get("termId")
    const sclassId = searchParams.get("sclassId")
    const subjectId = searchParams.get("subjectId")

    const where: any = {
      schoolId: session.id,
    }

    if (termId) where.termId = termId
    if (sclassId) where.sclassId = sclassId
    if (subjectId) where.subjectId = subjectId

    const exams = await prisma.exam.findMany({
      where,
      include: {
        subject: true,
        sclass: true,
        term: true,
        teacher: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
        results: {
          include: {
            student: {
              select: {
                id: true,
                name: true,
                rollNum: true,
              },
            },
          },
        },
      },
      orderBy: {
        startDate: "desc",
      },
    })

    return NextResponse.json(exams)
  } catch (error) {
    console.error("Error fetching exams:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getSession()
    if (!session || session.role !== "Admin") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()
    const {
      examName,
      examType,
      startDate,
      endDate,
      totalMarks,
      passingMarks,
      subjectId,
      sclassId,
      termId,
      teacherId,
    } = body

    const exam = await prisma.exam.create({
      data: {
        examName,
        examType,
        startDate: new Date(startDate),
        endDate: new Date(endDate),
        totalMarks: parseInt(totalMarks),
        passingMarks: parseInt(passingMarks),
        subjectId,
        sclassId,
        termId,
        teacherId,
        schoolId: session.id,
      },
      include: {
        subject: true,
        sclass: true,
        term: true,
        teacher: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
      },
    })

    return NextResponse.json(exam)
  } catch (error) {
    console.error("Error creating exam:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
