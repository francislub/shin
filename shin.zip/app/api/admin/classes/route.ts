import { NextRequest, NextResponse } from "next/server"
import { getSession } from "@/lib/auth"
import prisma from "@/lib/prisma"

export async function GET(request: NextRequest) {
  try {
    const session = await getSession()
    if (!session || session.role !== "Admin") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const classes = await prisma.sclass.findMany({
      where: {
        schoolId: session.id,
      },
      include: {
        students: {
          select: {
            id: true,
            name: true,
            rollNum: true,
          },
        },
        subjects: true,
        teachers: {
          select: {
            id: true,
            name: true,
          },
        },
      },
      orderBy: {
        sclassName: "asc",
      },
    })

    return NextResponse.json(classes)
  } catch (error) {
    console.error("Error fetching classes:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
