"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/context/auth-context"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { useToast } from "@/components/ui/use-toast"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BookOpen, Users, FileText, Save, Eye, Edit3, TrendingUp, Award, Clock } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

interface Class {
  id: string
  name: string
  section: string
  _count: {
    students: number
  }
}

interface Subject {
  id: string
  name: string
  code: string
  sclass: {
    id: string
    name: string
    section: string
  }
}

interface Student {
  id: string
  firstName: string
  lastName: string
  admissionNumber: string
  photoUrl?: string
  rollNumber: number
}

interface ExamResult {
  id: string
  marksObtained: number
  grade: string
  student: Student
  exam: {
    id: string
    examName: string
    examType: string
    totalMarks: number
    passingMarks: number
  }
}

interface StudentMark {
  studentId: string
  marks: number
}

const EXAM_TYPES = [
  { value: "BOT", label: "Beginning of Term", color: "bg-blue-500" },
  { value: "MID", label: "Mid-Term", color: "bg-yellow-500" },
  { value: "END", label: "End of Term", color: "bg-green-500" },
]

export default function TeacherExamsPage() {
  const { user, token } = useAuth()
  const { toast } = useToast()

  // State management
  const [classes, setClasses] = useState<Class[]>([])
  const [subjects, setSubjects] = useState<Subject[]>([])
  const [students, setStudents] = useState<Student[]>([])
  const [existingResults, setExistingResults] = useState<ExamResult[]>([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)

  // Form state
  const [selectedClass, setSelectedClass] = useState<string>("")
  const [selectedSubject, setSelectedSubject] = useState<string>("")
  const [selectedExamType, setSelectedExamType] = useState<string>("BOT")
  const [examName, setExamName] = useState<string>("")
  const [totalMarks, setTotalMarks] = useState<number>(100)
  const [studentMarks, setStudentMarks] = useState<StudentMark[]>([])

  // UI state
  const [activeTab, setActiveTab] = useState<string>("create")

  // Fetch classes on component mount
  useEffect(() => {
    if (token) {
      fetchClasses()
    }
  }, [token])

  // Fetch subjects when class changes
  useEffect(() => {
    if (selectedClass) {
      fetchSubjects(selectedClass)
      setSelectedSubject("")
    }
  }, [selectedClass])

  // Fetch students and existing results when class, subject, or exam type changes
  useEffect(() => {
    if (selectedClass && selectedSubject && selectedExamType) {
      fetchStudents()
      fetchExistingResults()
      generateExamName()
    }
  }, [selectedClass, selectedSubject, selectedExamType])

  const fetchClasses = async () => {
    try {
      setLoading(true)
      console.log("Fetching classes for teacher:", user?.id)

      const response = await fetch("/api/teacher/exams/classes", {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      })

      console.log("Classes response status:", response.status)

      if (!response.ok) {
        const errorData = await response.text()
        console.error("Classes fetch error:", errorData)
        throw new Error(`Failed to fetch classes: ${response.status}`)
      }

      const data = await response.json()
      console.log("Classes data received:", data)
      setClasses(data)

      if (data.length === 0) {
        toast({
          title: "No Classes Found",
          description: "You are not assigned to any classes yet.",
          variant: "default",
        })
      }
    } catch (error) {
      console.error("Error fetching classes:", error)
      toast({
        title: "Error",
        description: "Failed to load classes. Please try again.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const fetchSubjects = async (classId: string) => {
    try {
      console.log("Fetching subjects for class:", classId)

      const response = await fetch(`/api/teacher/exams/subjects?classId=${classId}`, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      })

      console.log("Subjects response status:", response.status)

      if (!response.ok) {
        const errorData = await response.text()
        console.error("Subjects fetch error:", errorData)
        throw new Error(`Failed to fetch subjects: ${response.status}`)
      }

      const data = await response.json()
      console.log("Subjects data received:", data)
      setSubjects(data)
      setSelectedSubject("")

      if (data.length === 0) {
        toast({
          title: "No Subjects Found",
          description: "You don't teach any subjects in this class.",
          variant: "default",
        })
      }
    } catch (error) {
      console.error("Error fetching subjects:", error)
      toast({
        title: "Error",
        description: "Failed to load subjects. Please try again.",
        variant: "destructive",
      })
    }
  }

  const fetchStudents = async () => {
    try {
      const response = await fetch(
        `/api/teacher/exams/students?classId=${selectedClass}&subjectId=${selectedSubject}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        },
      )

      if (!response.ok) throw new Error("Failed to fetch students")
      const data = await response.json()
      setStudents(data)

      // Initialize student marks
      const initialMarks = data.map((student: Student) => ({
        studentId: student.id,
        marks: 0,
      }))
      setStudentMarks(initialMarks)
    } catch (error) {
      console.error("Error fetching students:", error)
      toast({
        title: "Error",
        description: "Failed to load students. Please try again.",
        variant: "destructive",
      })
    }
  }

  const fetchExistingResults = async () => {
    try {
      const response = await fetch(
        `/api/teacher/exams/results?classId=${selectedClass}&subjectId=${selectedSubject}&examType=${selectedExamType}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        },
      )

      if (!response.ok) throw new Error("Failed to fetch results")
      const data = await response.json()
      setExistingResults(data)

      if (data.length > 0) {
        // Populate existing marks
        const existingMarks = data.map((result: ExamResult) => ({
          studentId: result.student.id,
          marks: result.marksObtained,
        }))
        setStudentMarks(existingMarks)
        setTotalMarks(data[0].exam.totalMarks)
        setExamName(data[0].exam.examName)
        setActiveTab("view")
      } else {
        setActiveTab("create")
      }
    } catch (error) {
      console.error("Error fetching existing results:", error)
    }
  }

  const generateExamName = () => {
    const examTypeLabel = EXAM_TYPES.find((type) => type.value === selectedExamType)?.label
    const subjectName = subjects.find((s) => s.id === selectedSubject)?.name
    if (examTypeLabel && subjectName) {
      setExamName(`${examTypeLabel} - ${subjectName}`)
    }
  }

  const handleMarkChange = (studentId: string, marks: number) => {
    const validMarks = Math.min(Math.max(0, marks), totalMarks)
    setStudentMarks((prev) =>
      prev.map((mark) => (mark.studentId === studentId ? { ...mark, marks: validMarks } : mark)),
    )
  }

  const handleSaveResults = async () => {
    if (!selectedClass || !selectedSubject || !examName || studentMarks.length === 0) {
      toast({
        title: "Error",
        description: "Please fill in all required fields and enter marks for students.",
        variant: "destructive",
      })
      return
    }

    try {
      setSaving(true)
      const response = await fetch("/api/teacher/exams/results", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          examName,
          examType: selectedExamType,
          totalMarks,
          subjectId: selectedSubject,
          classId: selectedClass,
          results: studentMarks,
        }),
      })

      if (!response.ok) throw new Error("Failed to save results")

      toast({
        title: "Success",
        description: "Exam results saved successfully!",
      })

      // Refresh data
      await fetchExistingResults()
    } catch (error) {
      console.error("Error saving results:", error)
      toast({
        title: "Error",
        description: "Failed to save exam results. Please try again.",
        variant: "destructive",
      })
    } finally {
      setSaving(false)
    }
  }

  const getInitials = (firstName: string, lastName: string) => {
    return `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase()
  }

  const calculatePercentage = (marks: number, total: number) => {
    return ((marks / total) * 100).toFixed(1)
  }

  const getGradeColor = (grade: string) => {
    const colors: Record<string, string> = {
      "A+": "text-green-600 bg-green-50 border-green-200",
      A: "text-green-600 bg-green-50 border-green-200",
      "B+": "text-blue-600 bg-blue-50 border-blue-200",
      B: "text-blue-600 bg-blue-50 border-blue-200",
      "C+": "text-yellow-600 bg-yellow-50 border-yellow-200",
      C: "text-yellow-600 bg-yellow-50 border-yellow-200",
      F: "text-red-600 bg-red-50 border-red-200",
    }
    return colors[grade] || "text-gray-600 bg-gray-50 border-gray-200"
  }

  const getClassStats = () => {
    if (existingResults.length === 0) return null

    const totalStudents = existingResults.length
    const passedStudents = existingResults.filter((r) => r.marksObtained >= r.exam.passingMarks).length
    const averageMarks = existingResults.reduce((sum, r) => sum + r.marksObtained, 0) / totalStudents
    const passPercentage = (passedStudents / totalStudents) * 100

    return {
      totalStudents,
      passedStudents,
      averageMarks: averageMarks.toFixed(1),
      passPercentage: passPercentage.toFixed(1),
    }
  }

  const stats = getClassStats()

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Exam Management</h1>
        <p className="text-muted-foreground">Create and manage exam results for your classes.</p>
      </div>
      <Separator />

      {/* Selection Controls */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BookOpen className="h-5 w-5" />
            Exam Configuration
          </CardTitle>
          <CardDescription>Select class, subject, and exam type to proceed.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-4">
            <div>
              <Label htmlFor="class">Class</Label>
              <Select value={selectedClass} onValueChange={setSelectedClass}>
                <SelectTrigger id="class">
                  <SelectValue placeholder="Select class" />
                </SelectTrigger>
                <SelectContent>
                  {classes.map((cls) => (
                    <SelectItem key={cls.id} value={cls.id}>
                      <div className="flex items-center justify-between w-full">
                        <span>
                          {cls.name} - {cls.section}
                        </span>
                        <Badge variant="secondary" className="ml-2">
                          {cls._count.students} students
                        </Badge>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="subject">Subject</Label>
              <Select
                value={selectedSubject}
                onValueChange={setSelectedSubject}
                disabled={!selectedClass || subjects.length === 0}
              >
                <SelectTrigger id="subject">
                  <SelectValue
                    placeholder={
                      !selectedClass
                        ? "Select a class first"
                        : subjects.length === 0
                          ? "No subjects available"
                          : "Select subject"
                    }
                  />
                </SelectTrigger>
                <SelectContent>
                  {subjects.map((subject) => (
                    <SelectItem key={subject.id} value={subject.id}>
                      {subject.name} ({subject.code})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="examType">Exam Type</Label>
              <Select value={selectedExamType} onValueChange={setSelectedExamType}>
                <SelectTrigger id="examType">
                  <SelectValue placeholder="Select exam type" />
                </SelectTrigger>
                <SelectContent>
                  {EXAM_TYPES.map((type) => (
                    <SelectItem key={type.value} value={type.value}>
                      <div className="flex items-center gap-2">
                        <div className={`w-3 h-3 rounded-full ${type.color}`} />
                        {type.label}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="totalMarks">Total Marks</Label>
              <Input
                id="totalMarks"
                type="number"
                value={totalMarks}
                onChange={(e) => setTotalMarks(Number.parseInt(e.target.value) || 100)}
                min={1}
                max={1000}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Main Content */}
      {selectedClass && selectedSubject && selectedExamType ? (
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="create" className="flex items-center gap-2">
              <Edit3 className="h-4 w-4" />
              {existingResults.length > 0 ? "Edit Results" : "Create Exam"}
            </TabsTrigger>
            <TabsTrigger value="view" disabled={existingResults.length === 0} className="flex items-center gap-2">
              <Eye className="h-4 w-4" />
              View Results
            </TabsTrigger>
          </TabsList>

          <TabsContent value="create" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  Exam Details
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-2">
                  <div>
                    <Label htmlFor="examName">Exam Name</Label>
                    <Input
                      id="examName"
                      value={examName}
                      onChange={(e) => setExamName(e.target.value)}
                      placeholder="Enter exam name"
                    />
                  </div>
                  <div className="flex items-end">
                    <Button
                      onClick={handleSaveResults}
                      disabled={saving || !examName || studentMarks.length === 0}
                      className="flex items-center gap-2"
                    >
                      <Save className="h-4 w-4" />
                      {saving ? "Saving..." : "Save Results"}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Student Marks ({students.length} students)
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {students.map((student) => {
                    const currentMark = studentMarks.find((m) => m.studentId === student.id)?.marks || 0
                    const percentage = calculatePercentage(currentMark, totalMarks)

                    return (
                      <div
                        key={student.id}
                        className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                      >
                        <div className="flex items-center gap-3">
                          <Avatar className="h-10 w-10">
                            {student.photoUrl ? (
                              <AvatarImage
                                src={student.photoUrl || "/placeholder.svg"}
                                alt={`${student.firstName} ${student.lastName}`}
                              />
                            ) : null}
                            <AvatarFallback>{getInitials(student.firstName, student.lastName)}</AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium">
                              {student.firstName} {student.lastName}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              Roll: {student.rollNumber} • {student.admissionNumber}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-4">
                          <div className="text-right">
                            <p className="text-sm text-muted-foreground">Percentage</p>
                            <p className="font-medium">{percentage}%</p>
                          </div>
                          <div className="flex items-center gap-2">
                            <Input
                              type="number"
                              className="w-20 text-center"
                              value={currentMark}
                              onChange={(e) => handleMarkChange(student.id, Number.parseInt(e.target.value) || 0)}
                              min={0}
                              max={totalMarks}
                            />
                            <span className="text-sm text-muted-foreground">/ {totalMarks}</span>
                          </div>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="view" className="space-y-4">
            {stats && (
              <div className="grid gap-4 md:grid-cols-4">
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2">
                      <Users className="h-4 w-4 text-blue-500" />
                      <div>
                        <p className="text-sm text-muted-foreground">Total Students</p>
                        <p className="text-2xl font-bold">{stats.totalStudents}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2">
                      <Award className="h-4 w-4 text-green-500" />
                      <div>
                        <p className="text-sm text-muted-foreground">Passed</p>
                        <p className="text-2xl font-bold">{stats.passedStudents}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2">
                      <TrendingUp className="h-4 w-4 text-purple-500" />
                      <div>
                        <p className="text-sm text-muted-foreground">Average</p>
                        <p className="text-2xl font-bold">{stats.averageMarks}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-orange-500" />
                      <div>
                        <p className="text-sm text-muted-foreground">Pass Rate</p>
                        <p className="text-2xl font-bold">{stats.passPercentage}%</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}

            <Card>
              <CardHeader>
                <CardTitle>Exam Results</CardTitle>
                <CardDescription>{existingResults.length > 0 && existingResults[0].exam.examName}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {existingResults.map((result) => {
                    const percentage = calculatePercentage(result.marksObtained, result.exam.totalMarks)
                    const isPassed = result.marksObtained >= result.exam.passingMarks

                    return (
                      <div key={result.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center gap-3">
                          <Avatar className="h-10 w-10">
                            {result.student.photoUrl ? (
                              <AvatarImage
                                src={result.student.photoUrl || "/placeholder.svg"}
                                alt={`${result.student.firstName} ${result.student.lastName}`}
                              />
                            ) : null}
                            <AvatarFallback>
                              {getInitials(result.student.firstName, result.student.lastName)}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium">
                              {result.student.firstName} {result.student.lastName}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              Roll: {result.student.rollNumber} • {result.student.admissionNumber}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-4">
                          <div className="text-right">
                            <p className="font-medium">
                              {result.marksObtained} / {result.exam.totalMarks}
                            </p>
                            <p className="text-sm text-muted-foreground">{percentage}%</p>
                          </div>
                          <Badge className={getGradeColor(result.grade)}>{result.grade}</Badge>
                          <Badge variant={isPassed ? "default" : "destructive"}>{isPassed ? "Pass" : "Fail"}</Badge>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      ) : (
        <Card>
          <CardContent className="flex h-[400px] items-center justify-center">
            <div className="text-center">
              <BookOpen className="mx-auto h-12 w-12 text-muted-foreground" />
              <h3 className="mt-4 text-lg font-semibold">Select Configuration</h3>
              <p className="mt-2 text-sm text-muted-foreground">
                Please select a class, subject, and exam type to get started.
              </p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
